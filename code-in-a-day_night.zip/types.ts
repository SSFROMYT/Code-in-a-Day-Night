
export interface Topic {
  title: string;
  explanation: string;
  codeExample: string;
  exercise: string;
}

export interface LearningPlan {
  language: string;
  topics: Topic[];
}

export type Theme = 'light' | 'dark' | 'christmas';

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}
