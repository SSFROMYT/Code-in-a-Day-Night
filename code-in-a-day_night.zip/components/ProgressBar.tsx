
import React from 'react';

interface ProgressBarProps {
    completed: number;
    total: number;
    isChristmas?: boolean;
}

export const ProgressBar: React.FC<ProgressBarProps> = ({ completed, total, isChristmas }) => {
    const percentage = total > 0 ? (completed / total) * 100 : 0;

    return (
        <div className="mb-6">
            <div className="flex justify-between items-center mb-1">
                <span className={`text-sm font-medium ${isChristmas ? 'text-green-200' : 'text-gray-700 dark:text-gray-300'}`}>
                    {isChristmas ? "🎁 Gifts Unwrapped" : "Your Adventure Progress"}
                </span>
                <span className={`text-sm font-medium ${isChristmas ? 'text-green-200' : 'text-gray-700 dark:text-gray-300'}`}>
                    {completed} / {total} {isChristmas ? 'Gifts' : 'Steps'}
                </span>
            </div>
            <div className={`w-full rounded-full h-3 transition-colors duration-500 ${isChristmas ? 'bg-red-900/50' : 'bg-gray-200 dark:bg-gray-700'}`}>
                <div 
                    className={`h-3 rounded-full transition-all duration-700 ease-out ${
                        isChristmas 
                        ? 'bg-gradient-to-r from-red-500 via-white to-red-500 bg-[length:20px_20px] animate-candycane' 
                        : 'bg-green-500'
                    }`} 
                    style={{ width: `${percentage}%` }}
                    aria-valuenow={percentage}
                    aria-valuemin={0}
                    aria-valuemax={100}
                    role="progressbar"
                    aria-label="Learning plan progress"
                ></div>
            </div>
            {isChristmas && (
                <style>{`
                    @keyframes candycane {
                        from { background-position: 0 0; }
                        to { background-position: 40px 0; }
                    }
                    .animate-candycane {
                        animation: candycane 2s linear infinite;
                        background-image: linear-gradient(
                            45deg,
                            rgba(255, 255, 255, 0.2) 25%,
                            transparent 25%,
                            transparent 50%,
                            rgba(255, 255, 255, 0.2) 50%,
                            rgba(255, 255, 255, 0.2) 75%,
                            transparent 75%,
                            transparent
                        );
                    }
                `}</style>
            )}
        </div>
    );
};
