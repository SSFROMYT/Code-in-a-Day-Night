
import React, { useState, useRef, useEffect } from 'react';
import { BotIcon } from './icons/BotIcon';
import { CloseIcon } from './icons/CloseIcon';
import { SendIcon } from './icons/SendIcon';
import { SnowflakeIcon } from './icons/SnowflakeIcon';
import { type ChatMessage } from '../types';

interface AssistantProps {
    sendMessage: (message: string) => Promise<void>;
    history: ChatMessage[];
    isAssistantLoading: boolean;
    isChristmas?: boolean;
}

export const Assistant: React.FC<AssistantProps> = ({ sendMessage, history, isAssistantLoading, isChristmas }) => {
    const [isOpen, setIsOpen] = useState(false);
    const [input, setInput] = useState('');
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    };

    useEffect(() => {
        if (isOpen) {
            scrollToBottom();
        }
    }, [history, isOpen, isAssistantLoading]);
    
    const handleSend = (e: React.FormEvent) => {
        e.preventDefault();
        if (input.trim()) {
            sendMessage(input);
            setInput('');
        }
    };

    if (!isOpen) {
        return (
            <button
                onClick={() => setIsOpen(true)}
                className={`fixed bottom-6 right-6 rounded-full p-4 shadow-2xl transition-all duration-300 transform hover:scale-110 active:scale-95 focus:outline-none focus:ring-2 focus:ring-offset-2 z-30
                    ${isChristmas 
                        ? 'bg-red-600 text-white ring-2 ring-yellow-400 hover:bg-red-500' 
                        : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500 dark:focus:ring-offset-gray-900'}`}
                aria-label="Open coding assistant"
            >
                {isChristmas ? <SnowflakeIcon className="w-8 h-8 animate-spin-slow" /> : <BotIcon className="w-8 h-8" />}
                <style>{`
                    @keyframes spin-slow {
                        from { transform: rotate(0deg); }
                        to { transform: rotate(360deg); }
                    }
                    .animate-spin-slow { animation: spin-slow 8s linear infinite; }
                `}</style>
            </button>
        );
    }
    
    return (
        <div className="fixed inset-0 z-50 flex items-end justify-center sm:justify-end sm:items-end p-0 sm:p-6" aria-modal="true" role="dialog">
            <div className="fixed inset-0 bg-black/40 backdrop-blur-sm transition-opacity" onClick={() => setIsOpen(false)}></div>
            <div className={`relative rounded-t-2xl sm:rounded-3xl w-full max-w-lg h-[80vh] sm:h-[70vh] flex flex-col shadow-2xl transform transition-transform duration-300 ease-out sm:translate-y-0 translate-y-full animate-slide-in-bottom
                ${isChristmas ? 'bg-[#1a0505] border-2 border-yellow-500/30 text-white' : 'bg-white dark:bg-gray-800 text-gray-800'}`}>
                
                {/* Header */}
                <div className={`flex items-center justify-between p-5 border-b flex-shrink-0
                    ${isChristmas ? 'border-red-900 bg-red-950/40' : 'border-gray-200 dark:border-gray-700'}`}>
                    <div className="flex items-center gap-3">
                        {isChristmas ? <SnowflakeIcon className="w-7 h-7 text-yellow-400" /> : <BotIcon className="w-7 h-7 text-blue-500" />}
                        <h3 className="text-xl font-black italic tracking-tight">
                            {isChristmas ? "Codey the Coding Elf" : "Codey Assistant"}
                        </h3>
                    </div>
                    <button onClick={() => setIsOpen(false)} className={`p-2 rounded-full transition-colors 
                        ${isChristmas ? 'text-red-400 hover:bg-red-900/50' : 'text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-700'}`} aria-label="Close assistant">
                        <CloseIcon className="w-6 h-6" />
                    </button>
                </div>

                {/* Messages */}
                <div className={`flex-1 p-4 overflow-y-auto space-y-4 ${isChristmas ? 'bg-gradient-to-b from-transparent to-red-950/10' : ''}`}>
                    {history.map((msg, index) => (
                        <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            <div className={`max-w-xs md:max-w-md p-4 rounded-2xl shadow-sm transition-all
                                ${msg.role === 'user' 
                                    ? (isChristmas ? 'bg-green-700 text-white rounded-br-sm border border-yellow-500/20' : 'bg-blue-500 text-white rounded-br-sm') 
                                    : (isChristmas ? 'bg-red-900/40 text-gray-100 rounded-bl-sm border border-red-800' : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-bl-sm')}`}>
                                <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                            </div>
                        </div>
                    ))}
                    {isAssistantLoading && (
                        <div className="flex justify-start">
                            <div className={`max-w-xs md:max-w-md p-4 rounded-2xl ${isChristmas ? 'bg-red-900/40' : 'bg-gray-100 dark:bg-gray-700'}`}>
                                <div className="flex items-center space-x-2">
                                    <div className={`w-2 h-2 rounded-full animate-bounce ${isChristmas ? 'bg-yellow-500' : 'bg-gray-500'}`}></div>
                                    <div className={`w-2 h-2 rounded-full animate-bounce [animation-delay:0.2s] ${isChristmas ? 'bg-green-500' : 'bg-gray-500'}`}></div>
                                    <div className={`w-2 h-2 rounded-full animate-bounce [animation-delay:0.4s] ${isChristmas ? 'bg-red-500' : 'bg-gray-500'}`}></div>
                                </div>
                            </div>
                        </div>
                    )}
                    <div ref={messagesEndRef} />
                </div>

                {/* Input */}
                <div className={`p-4 border-t flex-shrink-0 ${isChristmas ? 'border-red-900 bg-red-950/40' : 'border-gray-200 dark:border-gray-700'}`}>
                    <form onSubmit={handleSend} className="flex items-center gap-3">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            placeholder={isChristmas ? "Ask Santa's Elf..." : "Ask a question..."}
                            className={`flex-grow p-4 rounded-2xl border transition-all focus:ring-2 focus:outline-none 
                                ${isChristmas 
                                    ? 'bg-black/30 border-red-900 text-white placeholder-red-400 focus:ring-yellow-500' 
                                    : 'bg-white dark:bg-gray-900 border-gray-300 dark:border-gray-600 focus:ring-blue-500'}`}
                            aria-label="Chat message input"
                        />
                        <button type="submit" 
                            className={`rounded-2xl p-4 transition-all transform hover:scale-110 active:scale-95 disabled:cursor-not-allowed
                                ${isChristmas 
                                    ? 'bg-yellow-500 text-red-900 hover:bg-yellow-400 shadow-lg shadow-yellow-900/20' 
                                    : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500 dark:focus:ring-offset-gray-800 disabled:bg-blue-400'}`} 
                            disabled={isAssistantLoading} aria-label="Send message">
                            <SendIcon className="w-6 h-6" />
                        </button>
                    </form>
                </div>
                <style>{`
                    @keyframes slide-in-bottom {
                        from { transform: translateY(100%); }
                        to { transform: translateY(0); }
                    }
                    @media (min-width: 640px) {
                        @keyframes slide-in-bottom {
                            from { opacity: 0; transform: translateY(30px) scale(0.95); }
                            to { opacity: 1; transform: translateY(0) scale(1); }
                        }
                    }
                    .animate-slide-in-bottom { animation: slide-in-bottom 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275) forwards; }
                `}</style>
            </div>
        </div>
    );
};
