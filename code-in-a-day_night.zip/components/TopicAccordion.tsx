
import React from 'react';
import { type Topic } from '../types';
import { ChevronDownIcon } from './icons/ChevronDownIcon';
import { BookOpenIcon } from './icons/BookOpenIcon';
import { CodeIcon } from './icons/CodeIcon';
import { TargetIcon } from './icons/TargetIcon';
import { CheckCircleIcon } from './icons/CheckCircleIcon';

interface TopicAccordionProps {
  topic: Topic;
  index: number;
  isActive: boolean;
  isCompleted: boolean;
  onToggle: (index: number) => void;
  onComplete: (index: number) => void;
  isChristmas?: boolean;
}

export const TopicAccordion: React.FC<TopicAccordionProps> = ({ topic, index, isActive, isCompleted, onToggle, onComplete, isChristmas }) => {
  const borderColor = isCompleted 
    ? (isChristmas ? 'border-yellow-400 bg-green-900/30' : 'border-green-400 dark:border-green-600 bg-green-50/50 dark:bg-green-900/20')
    : (isChristmas ? 'border-red-800 bg-red-950/20' : 'border-gray-200 dark:border-gray-700');

  return (
    <div className={`border rounded-lg overflow-hidden transition-all duration-300 shadow-sm ${borderColor}`}>
      <button
        className={`w-full flex justify-between items-center p-4 text-left transition-colors
          ${isChristmas ? 'bg-red-900/20 hover:bg-red-900/40' : 'bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700'} focus:outline-none`}
        onClick={() => onToggle(index)}
        aria-expanded={isActive}
      >
        <div className="flex items-center gap-3">
            {isCompleted 
                ? <CheckCircleIcon className={`w-6 h-6 flex-shrink-0 ${isChristmas ? 'text-yellow-400' : 'text-green-500'}`} /> 
                : <span className={`flex items-center justify-center w-6 h-6 text-sm font-bold rounded-full flex-shrink-0 
                    ${isChristmas ? 'bg-red-600 text-white' : 'bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-300'}`}>
                    {index + 1}
                  </span>
            }
            <span className={`text-lg font-semibold text-left ${isChristmas ? 'text-white' : 'text-gray-800 dark:text-gray-200'}`}>{topic.title}</span>
        </div>
        <ChevronDownIcon
          className={`w-6 h-6 transform transition-transform duration-300 ${isActive ? 'rotate-180' : ''} 
            ${isChristmas ? 'text-yellow-500' : 'text-gray-500 dark:text-gray-400'}`}
        />
      </button>
      <div
        className={`transition-all duration-500 ease-in-out overflow-hidden ${isActive ? 'max-h-[2000px]' : 'max-h-0'}`}
      >
        <div className={`p-5 border-t bg-white dark:bg-gray-800/50 ${isChristmas ? 'border-red-900/50 bg-red-950/40' : 'border-gray-200 dark:border-gray-700'}`}>
          <div className="space-y-6">
            <div className="flex items-start gap-3">
              <BookOpenIcon className={`w-5 h-5 mt-1 flex-shrink-0 ${isChristmas ? 'text-yellow-400' : 'text-blue-500 dark:text-blue-400'}`} />
              <div>
                <h3 className={`text-md font-semibold mb-2 ${isChristmas ? 'text-yellow-400' : 'text-blue-600 dark:text-blue-400'}`}>The Holiday Spirit</h3>
                <p className={`whitespace-pre-wrap ${isChristmas ? 'text-gray-100' : 'text-gray-600 dark:text-gray-300'}`}>{topic.explanation}</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
                <CodeIcon className={`w-5 h-5 mt-1 flex-shrink-0 ${isChristmas ? 'text-green-400' : 'text-green-500 dark:text-green-400'}`} />
                <div>
                    <h3 className={`text-md font-semibold mb-2 ${isChristmas ? 'text-green-400' : 'text-green-600 dark:text-green-400'}`}>See it Sparkle</h3>
                    <pre className={`p-3 rounded-md text-sm overflow-x-auto ${isChristmas ? 'bg-black/50 text-green-300' : 'bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200'}`}>
                        <code>{topic.codeExample}</code>
                    </pre>
                </div>
            </div>
            <div className="flex items-start gap-3">
                <TargetIcon className={`w-5 h-5 mt-1 flex-shrink-0 ${isChristmas ? 'text-red-400' : 'text-purple-500 dark:text-purple-400'}`} />
                <div>
                    <h3 className={`text-md font-semibold mb-2 ${isChristmas ? 'text-red-400' : 'text-purple-600 dark:text-purple-400'}`}>Try It Yourself!</h3>
                    <p className={`whitespace-pre-wrap ${isChristmas ? 'text-gray-100' : 'text-gray-600 dark:text-gray-300'}`}>{topic.exercise}</p>
                </div>
            </div>
            {!isCompleted && (
                <div className={`pt-4 border-t flex justify-end ${isChristmas ? 'border-red-900/50' : 'border-gray-200 dark:border-gray-700'}`}>
                    <button
                        onClick={() => onComplete(index)}
                        className={`font-semibold py-2 px-5 rounded-md focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all transform hover:scale-105
                            ${isChristmas ? 'bg-green-600 text-white hover:bg-green-500 focus:ring-yellow-500' : 'bg-green-500 text-white hover:bg-green-600 focus:ring-green-500 dark:focus:ring-offset-gray-900'}`}
                    >
                        {isChristmas ? "🎁 Unwrap this Skill!" : "I Did It!"}
                    </button>
                </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
