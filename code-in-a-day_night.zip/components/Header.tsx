
import React from 'react';
import { type Theme } from '../types';
import { SunIcon } from './icons/SunIcon';
import { MoonIcon } from './icons/MoonIcon';
import { GiftIcon } from './icons/GiftIcon';
import { SnowflakeIcon } from './icons/SnowflakeIcon';

interface HeaderProps {
  theme: Theme;
  toggleTheme: () => void;
}

export const Header: React.FC<HeaderProps> = ({ theme, toggleTheme }) => {
  const isChristmas = theme === 'christmas';

  return (
    <header className={`py-4 px-6 md:px-8 flex items-center justify-between backdrop-blur-md sticky top-0 z-10 border-b transition-colors duration-500
      ${isChristmas ? 'bg-red-900/40 border-yellow-500/30' : 'bg-white/50 dark:bg-gray-900/50 border-gray-200 dark:border-gray-800'}`}>
      <h1 className="text-2xl font-bold flex items-center gap-2">
        {isChristmas && <SnowflakeIcon className="w-6 h-6 text-yellow-400 animate-pulse" />}
        <span className={isChristmas ? 'text-white' : 'text-gray-800 dark:text-gray-100'}>
          Your <span className={isChristmas ? 'text-green-400' : 'text-blue-500'}>Coding</span> <span className={isChristmas ? 'text-yellow-400' : 'text-indigo-400'}>Gifts</span>
        </span>
      </h1>
      <div className="flex items-center gap-2">
        <button
          onClick={toggleTheme}
          className={`p-2 rounded-full transition-all duration-300 transform hover:scale-110 focus:outline-none focus:ring-2 focus:ring-offset-2 
            ${isChristmas ? 'bg-green-700 text-yellow-300 hover:bg-green-600 focus:ring-yellow-500' : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700 focus:ring-blue-500'}`}
          aria-label="Toggle holiday theme"
        >
          {theme === 'light' ? <MoonIcon className="w-6 h-6" /> : theme === 'dark' ? <GiftIcon className="w-6 h-6" /> : <SunIcon className="w-6 h-6" />}
        </button>
      </div>
    </header>
  );
};
