
import { GoogleGenAI, Type, Chat } from "@google/genai";
import { type LearningPlan } from '../types';

if (!process.env.API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const learningPlanSchema = {
  type: Type.OBJECT,
  properties: {
    language: {
      type: Type.STRING,
      description: "The programming language requested by the user."
    },
    topics: {
      type: Type.ARRAY,
      description: "A list of topics to learn the language in a day.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: {
            type: Type.STRING,
            description: "The title of the topic."
          },
          explanation: {
            type: Type.STRING,
            description: "A concise and clear explanation of the topic for a beginner."
          },
          codeExample: {
            type: Type.STRING,
            description: "A simple, runnable code example illustrating the topic."
          },
          exercise: {
            type: Type.STRING,
            description: "A small, practical exercise for the user to practice the concept."
          },
        },
        required: ["title", "explanation", "codeExample", "exercise"],
      },
    },
  },
  required: ["language", "topics"],
};

export const generateLearningPlan = async (language: string, isChristmas: boolean = false): Promise<LearningPlan> => {
  try {
    const festiveInstruction = isChristmas 
        ? "Additionally, give the titles and explanations a fun holiday/Christmas twist! Use metaphors like wrapping presents, building snowmen, or hanging ornaments."
        : "";
    
    const prompt = `Generate a concise, single-day learning plan for a complete beginner to learn the basics of the "${language}" programming language. The plan should be structured into about 8-10 core topics, starting from the absolute basics and progressing logically. Explain everything as if you were talking to a curious 13-year-old who is excited to learn to code. For each topic, provide a simple explanation, a clear code example, and a small practice exercise. The goal is to give someone a solid foundation in one intensive day or night session. ${festiveInstruction}`;

    const response = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: learningPlanSchema,
        temperature: 0.7,
      },
    });

    const jsonText = response.text.trim();
    const parsedPlan = JSON.parse(jsonText);

    if (parsedPlan && Array.isArray(parsedPlan.topics)) {
        return parsedPlan as LearningPlan;
    } else {
        throw new Error("Invalid response structure from Gemini API.");
    }

  } catch (error) {
    console.error("Error generating learning plan:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to generate learning plan: ${error.message}`);
    }
    throw new Error("An unknown error occurred while generating the learning plan.");
  }
};

let chatInstance: Chat | null = null;
let currentLanguage: string | null = null;
let currentThemeMode: string | null = null;

export const sendMessageToAssistant = async (message: string, language: string, isChristmas: boolean = false): Promise<string> => {
  const themeKey = isChristmas ? 'christmas' : 'standard';
  if (!chatInstance || currentLanguage !== language || currentThemeMode !== themeKey) {
    currentLanguage = language;
    currentThemeMode = themeKey;
    
    const christmasSpirit = isChristmas 
        ? "You are now Codey the Coding Elf! You are extra jolly, use emojis like 🎄, 🎁, ❄️, and 🎅. Your tone is like a helpful elf at the North Pole who loves teaching kids how to build digital toys with code. Use Christmas analogies for everything!"
        : "Your tone should be fun, simple, and exciting. Explain concepts clearly, using simple words and analogies.";

    chatInstance = ai.chats.create({
      model: 'gemini-2.5-flash',
      config: {
        systemInstruction: `You are a friendly and super encouraging programming tutor named 'Codey'. You are helping a young student (around 13 years old) learn the ${language} programming language. ${christmasSpirit} Use markdown for code snippets when necessary. If this is the first message from the user, greet them warmly and introduce yourself as their personal coding buddy.`,
      },
    });
  }
  
  try {
    const response = await chatInstance.sendMessage({ message });
    return response.text;
  } catch (error) {
    console.error("Error sending message to assistant:", error);
    if (error instanceof Error) {
        throw new Error(`Failed to get response from assistant: ${error.message}`);
    }
    throw new Error("An unknown error occurred while communicating with the assistant.");
  }
};
