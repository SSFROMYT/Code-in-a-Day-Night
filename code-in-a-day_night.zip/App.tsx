
import React, { useState, useEffect, useCallback } from 'react';
import { type Theme, type LearningPlan, type ChatMessage } from './types';
import { Header } from './components/Header';
import { TopicAccordion } from './components/TopicAccordion';
import { ProgressBar } from './components/ProgressBar';
import { Assistant } from './components/Assistant';
import { Snowfall } from './components/Snowfall';
import { generateLearningPlan, sendMessageToAssistant } from './services/geminiService';

const App: React.FC = () => {
  const [theme, setTheme] = useState<Theme>('christmas');
  const [language, setLanguage] = useState<string>('');
  const [learningPlan, setLearningPlan] = useState<LearningPlan | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [activeTopicIndex, setActiveTopicIndex] = useState<number | null>(0);

  const [completedTopics, setCompletedTopics] = useState<boolean[]>([]);
  const [isAssistantLoading, setIsAssistantLoading] = useState<boolean>(false);
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);

  useEffect(() => {
    const root = window.document.documentElement;
    root.classList.remove('dark', 'christmas-theme');
    if (theme === 'dark') {
      root.classList.add('dark');
    } else if (theme === 'christmas') {
      root.classList.add('dark'); // Christmas theme uses dark base for contrast
    }
  }, [theme]);

  const toggleTheme = () => {
    setTheme((prevTheme) => {
      if (prevTheme === 'light') return 'dark';
      if (prevTheme === 'dark') return 'christmas';
      return 'light';
    });
  };
  
  const handleToggleTopic = (index: number) => {
    setActiveTopicIndex(prevIndex => prevIndex === index ? null : index);
  };

  const handleCompleteTopic = (index: number) => {
    setCompletedTopics(prev => {
        const newCompleted = [...prev];
        newCompleted[index] = true;
        return newCompleted;
    });
  };

  const handleGeneratePlan = useCallback(async (event: React.FormEvent) => {
    event.preventDefault();
    if (!language.trim()) {
      setError("Please enter a programming language.");
      return;
    }

    setIsLoading(true);
    setError(null);
    setLearningPlan(null);
    setActiveTopicIndex(0);
    setCompletedTopics([]);
    setChatHistory([]);

    try {
      const plan = await generateLearningPlan(language, theme === 'christmas');
      setLearningPlan(plan);
      setCompletedTopics(new Array(plan.topics.length).fill(false));
      
      setIsAssistantLoading(true);
      const firstMessage = await sendMessageToAssistant("Hello!", language, theme === 'christmas');
      setChatHistory([{ role: 'model', text: firstMessage }]);

    } catch (err) {
      setError(err instanceof Error ? err.message : "An unexpected error occurred.");
    } finally {
      setIsLoading(false);
      setIsAssistantLoading(false);
    }
  }, [language, theme]);

  const handleSendMessage = useCallback(async (message: string) => {
    if (!learningPlan) return;

    const newHistory: ChatMessage[] = [...chatHistory, { role: 'user', text: message }];
    setChatHistory(newHistory);
    setIsAssistantLoading(true);

    try {
        const responseText = await sendMessageToAssistant(message, learningPlan.language, theme === 'christmas');
        setChatHistory([...newHistory, { role: 'model', text: responseText }]);
    } catch (err) {
        const errorMessage = err instanceof Error ? err.message : "Sorry, I couldn't respond.";
        setChatHistory([...newHistory, { role: 'model', text: errorMessage }]);
    } finally {
        setIsAssistantLoading(false);
    }
  }, [chatHistory, learningPlan, theme]);
  
  const completedCount = completedTopics.filter(Boolean).length;
  const isChristmas = theme === 'christmas';

  return (
    <div className={`min-h-screen text-gray-900 dark:text-gray-100 font-sans transition-colors duration-500 overflow-x-hidden
      ${isChristmas ? 'bg-[#0a2012] bg-gradient-to-b from-[#0a2012] to-[#1a0505]' : 'bg-gray-100 dark:bg-gray-900'}`}>
      
      {isChristmas && <Snowfall />}
      
      <Header theme={theme} toggleTheme={toggleTheme} />
      
      <main className="container mx-auto p-4 md:p-8 relative z-1">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className={`text-3xl md:text-5xl font-extrabold mb-4 transition-all duration-700
            ${isChristmas ? 'text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-yellow-400 to-green-500 animate-pulse' : ''}`}>
            {isChristmas ? "Unwrap Your Coding Gift!" : "Start Your Coding Adventure!"}
          </h2>
          <p className={`text-lg mb-8 ${isChristmas ? 'text-green-200' : 'text-gray-600 dark:text-gray-400'}`}>
            {isChristmas 
              ? "Ho Ho Ho! What skill should we wrap up today? Our coding elf is ready to build a festive path just for you!" 
              : "What do you want to learn? Type a language like Python or JavaScript, and our AI friend will create a fun, step-by-step plan just for you!"}
          </p>

          <form onSubmit={handleGeneratePlan} className="flex flex-col sm:flex-row gap-3 mb-8">
            <input
              type="text"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              placeholder={isChristmas ? "🎁 e.g., Ruby, Go, C++..." : "e.g., Python, JavaScript, Lua..."}
              className={`flex-grow p-4 rounded-xl border transition-all duration-300 focus:ring-2 focus:outline-none 
                ${isChristmas 
                  ? 'bg-red-900/30 border-yellow-500/50 text-white placeholder-red-300 focus:ring-yellow-500' 
                  : 'bg-white dark:bg-gray-800 border-gray-300 dark:border-gray-600 focus:ring-blue-500'}`}
              disabled={isLoading}
            />
            <button
              type="submit"
              className={`font-bold py-4 px-8 rounded-xl focus:outline-none focus:ring-2 focus:ring-offset-2 transition-all transform hover:scale-105 active:scale-95 disabled:cursor-not-allowed
                ${isChristmas 
                  ? 'bg-green-600 text-white hover:bg-green-500 focus:ring-yellow-500 shadow-lg shadow-green-900/50' 
                  : 'bg-blue-600 text-white hover:bg-blue-700 focus:ring-blue-500 dark:focus:ring-offset-gray-900 disabled:bg-blue-400 dark:disabled:bg-blue-800'}`}
              disabled={isLoading}
            >
              {isLoading ? (isChristmas ? '🎄 Loading Joy...' : 'Creating Plan...') : (isChristmas ? '🌟 Create My Holiday Plan' : 'Create My Plan')}
            </button>
          </form>
        </div>

        <div className="max-w-3xl mx-auto">
          {isLoading && (
            <div className="flex flex-col items-center justify-center text-center p-8">
              <div className={`w-16 h-16 border-4 border-t-transparent rounded-full animate-spin mb-4 
                ${isChristmas ? 'border-yellow-500' : 'border-blue-500'}`}></div>
              <p className={`text-xl font-bold ${isChristmas ? 'text-yellow-400' : ''}`}>
                {isChristmas ? "Preparing the sleigh..." : "Building your learning path..."}
              </p>
              <p className={isChristmas ? 'text-green-300' : 'text-gray-500'}>
                {isChristmas ? "Your digital gift is being wrapped with care!" : "Your adventure is just a moment away!"}
              </p>
            </div>
          )}

          {error && (
            <div className="bg-red-100 dark:bg-red-900/50 border border-red-400 text-red-700 dark:text-red-300 px-4 py-3 rounded-md text-center animate-bounce" role="alert">
              <strong className="font-bold">Oops! 🎅 </strong>
              <span className="block sm:inline">{error}</span>
            </div>
          )}

          {learningPlan && (
            <div className="mt-8 animate-slide-in-bottom">
              <h3 className={`text-4xl font-black mb-6 text-center ${isChristmas ? 'text-white' : ''}`}>
                {isChristmas ? '✨ Your ' : 'Your '}
                <span className={isChristmas ? 'text-yellow-400 underline decoration-red-500' : 'text-blue-500 dark:text-blue-400'}>
                  {learningPlan.language}
                </span> 
                {isChristmas ? ' Masterpiece!' : ' Adventure!'}
              </h3>
              <ProgressBar completed={completedCount} total={learningPlan.topics.length} isChristmas={isChristmas} />
              <div className="space-y-4">
                {learningPlan.topics.map((topic, index) => (
                  <TopicAccordion
                    key={index}
                    topic={topic}
                    index={index}
                    isActive={index === activeTopicIndex}
                    isCompleted={completedTopics[index]}
                    onToggle={handleToggleTopic}
                    onComplete={handleCompleteTopic}
                    isChristmas={isChristmas}
                  />
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
      {learningPlan && (
        <Assistant 
          sendMessage={handleSendMessage} 
          history={chatHistory} 
          isAssistantLoading={isAssistantLoading} 
          isChristmas={isChristmas} 
        />
      )}
    </div>
  );
};

export default App;
